OpenDUNE Hebrew localization -- drop-in data files
===================================================

Copy every file in this archive into your Dune II data directory (the
same folder as DUNE.PAK, ATRE.PAK, etc. -- OpenDUNE's bin/data/ if
that's where you installed it). Nothing here shares a filename with an
original game file, so this will never overwrite anything already
there.

Then set `language=hebrew` in opendune.ini and launch the game.

Requires an OpenDUNE build with Hebrew support (this project's
`hebrew` branch) -- these files alone do nothing against a stock
OpenDUNE build or the original DOS DUNE2.EXE.

Not included: in-mission strategic-map narration (REGIONA/H/O.INI).
That file is generated from your own copy of the original game data
and isn't redistributable the same way -- see hebrew/README.md /
hebrew/tools/build_regions.py in the project source if you want it.
